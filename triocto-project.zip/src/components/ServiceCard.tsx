import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import * as Icons from "lucide-react";
import { useQuote } from "./QuoteProvider";
import type { Service } from "@/data/services";

export function ServiceCard({ service, detailed = false }: { service: Service; detailed?: boolean }) {
  const { open } = useQuote();
  const Icon = (Icons as any)[service.icon] ?? Icons.Sparkles;
  return (
    <div className="group relative glass rounded-2xl p-6 hover-lift overflow-hidden">
      <div className="absolute -top-12 -right-12 h-32 w-32 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" style={{ background: "radial-gradient(circle, oklch(0.65 0.22 255 / 0.5), transparent)" }} />
      <div className="relative">
        <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl gradient-brand glow-blue mb-4 group-hover:scale-110 transition-transform">
          <Icon className="h-6 w-6 text-white" />
        </div>
        <h3 className="font-display text-xl font-bold mb-2">{service.title}</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">{service.short}</p>
        {detailed && (
          <ul className="mt-4 space-y-1.5 text-sm">
            {service.features.map((f) => (
              <li key={f} className="flex items-center gap-2 text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full gradient-brand" />
                {f}
              </li>
            ))}
          </ul>
        )}
        <div className="mt-5 flex items-center gap-3">
          <Link
            to="/services/$slug"
            params={{ slug: service.slug }}
            className="inline-flex items-center gap-1 text-sm font-semibold text-[var(--neon-blue)] hover:gap-2 transition-all"
          >
            Read More <ArrowRight className="h-4 w-4" />
          </Link>
          <button
            onClick={() => open(service.title)}
            className="text-sm font-semibold text-[var(--neon-red)] hover:underline"
          >
            Get Quote
          </button>
        </div>
      </div>
    </div>
  );
}
