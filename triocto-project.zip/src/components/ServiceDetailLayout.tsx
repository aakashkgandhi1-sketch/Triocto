import { Link } from "@tanstack/react-router";
import { Check, Sparkles, Target, Award, Phone } from "lucide-react";
import * as Icons from "lucide-react";
import { TechBackground } from "./TechBackground";
import { Reveal } from "./Reveal";
import { useQuote } from "./QuoteProvider";
import type { Service } from "@/data/services";
import { BRAND } from "@/data/brand";

export function ServiceDetailLayout({ service }: { service: Service }) {
  const { open } = useQuote();
  const Icon = (Icons as any)[service.icon] ?? Icons.Sparkles;

  const benefits = [
    "Tailored to your business goals",
    "Premium quality and craft",
    "Transparent communication",
    "On-time delivery, every time",
    "Scalable, future-ready solutions",
    "Post-launch support included",
  ];

  const why = [
    { icon: Sparkles, title: "Innovative Approach", text: "Modern stack, modern thinking. We build like the best in the industry." },
    { icon: Target, title: "Goal-Oriented", text: "Every decision is tied back to results that matter to your business." },
    { icon: Award, title: "Proven Quality", text: "Years of experience delivering work clients are proud to ship." },
  ];

  const steps = [
    { n: "01", t: "Discovery", d: "Deep dive into your goals, audience, and requirements." },
    { n: "02", t: "Strategy", d: "A clear roadmap, timeline, and deliverables before we build." },
    { n: "03", t: "Build", d: "Design, develop, iterate — with you in the loop the whole way." },
    { n: "04", t: "Launch & Grow", d: "Deploy, measure, optimize, and scale your success." },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative pt-20 pb-24 overflow-hidden">
        <TechBackground variant="hero" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl gradient-brand glow-mix mb-6 animate-pop">
              <Icon className="h-8 w-8 text-white" />
            </div>
            <p className="text-xs tracking-[0.3em] text-[var(--neon-blue)] uppercase mb-3">TRIOCTO Service</p>
            <h1 className="font-display text-4xl sm:text-6xl font-bold mb-5">
              <span className="gradient-text">{service.title}</span>
            </h1>
            <p className="text-lg text-muted-foreground">{service.short}</p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <button onClick={() => open(service.title)} className="rounded-full gradient-brand px-7 py-3 text-sm font-semibold text-white animate-pulse-glow">Book Now</button>
              <Link to="/contact" className="rounded-full glass px-7 py-3 text-sm font-semibold hover:bg-white/10 transition-colors">Contact Us</Link>
            </div>
          </div>
        </div>
      </section>

      {/* Feature cards */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {service.features.map((f, i) => (
            <Reveal key={f} delay={i * 100}>
              <div className="glass rounded-2xl p-5 text-center hover-lift">
                <div className="mx-auto mb-3 h-10 w-10 rounded-xl gradient-brand glow-blue flex items-center justify-center">
                  <Check className="h-5 w-5 text-white" />
                </div>
                <p className="font-semibold text-sm">{f}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Main explanation */}
      <section className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-16">
        <Reveal>
          <p className="text-xs tracking-[0.3em] text-[var(--neon-red)] uppercase mb-3">About this service</p>
          <h2 className="font-display text-3xl sm:text-5xl font-bold mb-6">{service.heading}</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">{service.description}</p>
        </Reveal>
      </section>

      {/* Benefits */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <Reveal className="text-center mb-10">
          <h2 className="font-display text-3xl sm:text-4xl font-bold">Benefits of Working With Us</h2>
        </Reveal>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {benefits.map((b, i) => (
            <Reveal key={b} delay={i * 80}>
              <div className="glass rounded-xl p-5 flex items-start gap-3 hover-lift">
                <span className="h-6 w-6 rounded-full gradient-brand flex items-center justify-center shrink-0">
                  <Check className="h-3.5 w-3.5 text-white" />
                </span>
                <span className="text-sm">{b}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Why TRIOCTO */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <Reveal className="text-center mb-12">
          <h2 className="font-display text-3xl sm:text-4xl font-bold">Why Choose <span className="gradient-text">TRIOCTO</span></h2>
        </Reveal>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {why.map((w, i) => (
            <Reveal key={w.title} delay={i * 120}>
              <div className="glass rounded-2xl p-6 hover-lift h-full">
                <w.icon className="h-7 w-7 text-[var(--neon-blue)] mb-3" />
                <h3 className="font-display text-xl font-bold mb-2">{w.title}</h3>
                <p className="text-sm text-muted-foreground">{w.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Process */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <Reveal className="text-center mb-12">
          <h2 className="font-display text-3xl sm:text-4xl font-bold">Our Process</h2>
        </Reveal>
        <div className="relative grid grid-cols-1 md:grid-cols-4 gap-5">
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-px" style={{ background: "linear-gradient(90deg, transparent, oklch(0.65 0.22 255 / 0.6), oklch(0.65 0.25 25 / 0.6), transparent)" }} />
          {steps.map((s, i) => (
            <Reveal key={s.n} delay={i * 150}>
              <div className="relative glass rounded-2xl p-6 hover-lift">
                <span className="absolute -top-3 -right-3 inline-flex h-10 w-10 items-center justify-center rounded-full gradient-brand text-white font-display font-bold text-sm glow-mix">{s.n}</span>
                <h3 className="font-display text-lg font-bold mb-1">{s.t}</h3>
                <p className="text-sm text-muted-foreground">{s.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="relative glass-strong rounded-3xl p-10 sm:p-14 text-center overflow-hidden">
          <TechBackground />
          <h2 className="relative font-display text-3xl sm:text-5xl font-bold mb-4">
            Ready to launch your <span className="gradient-text">{service.title.toLowerCase()}</span> project?
          </h2>
          <p className="relative text-muted-foreground mb-7 max-w-2xl mx-auto">
            Let's build something powerful together. Talk to TRIOCTO today and get a free, no-obligation consultation.
          </p>
          <div className="relative flex flex-wrap justify-center gap-3">
            <button onClick={() => open(service.title)} className="rounded-full gradient-brand px-7 py-3 text-sm font-semibold text-white animate-pulse-glow">Book Now</button>
            <a href={`tel:${BRAND.phoneRaw}`} className="rounded-full glass px-7 py-3 text-sm font-semibold inline-flex items-center gap-2 hover:bg-white/10 transition-colors">
              <Phone className="h-4 w-4" /> {BRAND.phone}
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
