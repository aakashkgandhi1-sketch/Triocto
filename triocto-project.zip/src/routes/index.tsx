import { createFileRoute, Link } from "@tanstack/react-router";
import { Phone, ArrowRight, Star } from "lucide-react";
import { TechBackground } from "@/components/TechBackground";
import { ServiceTicker } from "@/components/ServiceTicker";
import { Counter } from "@/components/Counter";
import { Reveal } from "@/components/Reveal";
import { ServiceCard } from "@/components/ServiceCard";
import { useQuote } from "@/components/QuoteProvider";
import { services } from "@/data/services";
import { BRAND } from "@/data/brand";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "TRIOCTO — Build Software Products, Faster. Better." },
      { name: "description", content: "TRIOCTO is a premium digital agency for websites, apps, ecommerce, SEO and digital marketing. Build the future of your brand." },
      { property: "og:title", content: "TRIOCTO — Build Software Products, Faster. Better." },
      { property: "og:description", content: "Premium digital technology agency for websites, apps, ecommerce, SEO and growth." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Home,
});

function Home() {
  const { open } = useQuote();
  const previewServices = services.slice(0, 8);

  const counters = [
    { n: 1.5, s: "+", label: "Years of Experience", decimals: 1 },
    { n: 10, s: "+", label: "Projects Completed" },
    { n: 10, s: "+", label: "Happy Clients" },
    { n: 24, s: "/7", label: "Support Available" },
  ];

  const steps = [
    { n: "01", t: "Research Project", d: "Understand your goals, audience, market." },
    { n: "02", t: "Evaluate Plans", d: "Strategy, scope, timeline, deliverables." },
    { n: "03", t: "Website Development", d: "Design and engineer at premium quality." },
    { n: "04", t: "Digital Marketing", d: "Launch, grow, scale, measure results." },
  ];

  const techs = ["HTML", "CSS", "JavaScript", "React", "WordPress", "Shopify", "WooCommerce", "SEO", "Google Ads", "Meta Ads", "Hosting", "Cloud"];

  const testimonials = [
    { name: "Sheree Blair", text: "Great experience with TRIOCTO in web design and development. Truly the best opportunity to work with." },
    { name: "Ingrid Levine", text: "I'm so impressed — fantastic job on our website and very affordable. Highly recommend." },
    { name: "Laura Kakulu", text: "TRIOCTO was extremely efficient. Excellent communication and a beautifully mobile-compatible result." },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden pt-20 pb-28 sm:pt-28 sm:pb-36">
        <TechBackground variant="hero" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-4xl text-center">
            <Reveal>
              <p className="inline-block text-[10px] sm:text-xs tracking-[0.35em] uppercase glass rounded-full px-4 py-2 mb-6 text-muted-foreground">
                Digital Marketing, AI Marketing & Website Development Service Provider
              </p>
            </Reveal>
            <Reveal delay={100}>
              <h1 className="font-display text-5xl sm:text-7xl lg:text-8xl font-bold leading-[1.05] tracking-tight">
                <span className="gradient-text">AI-Powered Marketing</span> & Digital Solutions for Faster Business Growth.
              </h1>
            </Reveal>
            <Reveal delay={200}>
              <p className="mt-5 text-base sm:text-lg font-medium max-w-2xl mx-auto leading-relaxed">
                We build websites, apps, and intelligent marketing systems that attract leads, automate processes, and scale your business.
              </p>
            </Reveal>
            <Reveal delay={300}>
              <p className="mt-4 text-sm sm:text-base text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Welcome to TRIOCTO, where innovation meets excellence in Digital Marketing, AI Marketing, and Website Development. We create modern websites, apps, ecommerce platforms, AI-powered marketing strategies, and digital solutions that help businesses grow faster online.
              </p>
            </Reveal>

            <Reveal delay={400}>
              <div className="mt-9 flex flex-wrap justify-center gap-3">
                <button onClick={() => open()} className="group inline-flex items-center gap-2 rounded-full gradient-brand px-7 py-3.5 text-sm font-semibold text-white animate-pulse-glow">
                  GET QUOTE <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </button>
                <a href={`tel:${BRAND.phoneRaw}`} className="inline-flex items-center gap-2 rounded-full glass px-7 py-3.5 text-sm font-semibold hover:bg-white/10 transition-colors">
                  <Phone className="h-4 w-4" /> CALL NOW
                </a>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <ServiceTicker />

      {/* About preview */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <Reveal>
            <p className="text-xs tracking-[0.3em] text-[var(--neon-blue)] uppercase mb-3">About TRIOCTO</p>
            <h2 className="font-display text-4xl sm:text-5xl font-bold leading-tight">
              How We Became <span className="gradient-text">Best Among Others?</span>
            </h2>
            <p className="mt-5 text-muted-foreground leading-relaxed">
              At TRIOCTO, we understand each client's unique needs and create digital marketing and website development solutions aligned with business goals.
            </p>
            <ul className="mt-6 grid sm:grid-cols-2 gap-3">
              {["Prioritizing your goals and vision", "Proven track record and successful projects", "Commitment to quality and innovation", "Affordable and scalable solutions", "Dedicated support", "Fast delivery"].map((b) => (
                <li key={b} className="flex items-start gap-2 text-sm">
                  <span className="mt-1.5 h-1.5 w-1.5 rounded-full gradient-brand shrink-0" /> {b}
                </li>
              ))}
            </ul>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/about-us" className="rounded-full glass px-6 py-3 text-sm font-semibold hover:bg-white/10 transition-colors">About Us</Link>
              <button onClick={() => open()} className="rounded-full gradient-brand px-6 py-3 text-sm font-semibold text-white">GET FREE QUOTE</button>
            </div>
          </Reveal>
          <Reveal delay={200}>
            <div className="relative aspect-square max-w-md ml-auto">
              <div className="absolute inset-0 rounded-3xl glass-strong" />
              <div className="absolute inset-6 rounded-2xl gradient-brand opacity-20 blur-2xl" />
              <div className="absolute inset-8 rounded-2xl glass flex items-center justify-center">
                <div className="text-center p-6">
                  <p className="font-display text-7xl font-bold gradient-text">1.5+</p>
                  <p className="mt-2 text-sm uppercase tracking-widest text-muted-foreground">Years Crafting Digital</p>
                </div>
              </div>
              <span className="absolute top-4 right-4 h-3 w-3 rounded-full bg-[var(--neon-blue)] glow-blue animate-pulse" />
              <span className="absolute bottom-6 left-4 h-2 w-2 rounded-full bg-[var(--neon-red)] glow-red animate-pulse" />
            </div>
          </Reveal>
        </div>
      </section>

      {/* Counters */}
      <section className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <Reveal className="text-center mb-12">
          <p className="text-xs tracking-[0.3em] text-[var(--neon-red)] uppercase mb-2">By the numbers</p>
          <h2 className="font-display text-4xl sm:text-5xl font-bold">TRIOCTO In Numbers</h2>
        </Reveal>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
          {counters.map((c, i) => (
            <Reveal key={c.label} delay={i * 150}>
              <div className="glass-strong rounded-2xl p-7 text-center hover-lift">
                <Counter to={c.n} suffix={c.s} decimals={(c as any).decimals ?? 0} />
                <p className="mt-3 text-sm text-muted-foreground">{c.label}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Services preview */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <Reveal className="text-center max-w-2xl mx-auto mb-12">
          <p className="text-xs tracking-[0.3em] text-[var(--neon-blue)] uppercase mb-2">What we do</p>
          <h2 className="font-display text-4xl sm:text-5xl font-bold">
            Best Services We Can <span className="gradient-text">Offer For You!</span>
          </h2>
        </Reveal>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {previewServices.map((s, i) => (
            <Reveal key={s.slug} delay={i * 80}>
              <ServiceCard service={s} />
            </Reveal>
          ))}
        </div>
        <div className="mt-10 text-center">
          <Link to="/services" className="inline-flex items-center gap-2 rounded-full gradient-brand px-7 py-3 text-sm font-semibold text-white animate-pulse-glow">
            View All Services <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* Process */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <Reveal className="text-center mb-12">
          <h2 className="font-display text-4xl sm:text-5xl font-bold">
            We Follow These <span className="gradient-text">Flawless Processes!</span>
          </h2>
        </Reveal>
        <div className="relative grid grid-cols-1 md:grid-cols-4 gap-5">
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-px" style={{ background: "linear-gradient(90deg, transparent, oklch(0.65 0.22 255 / 0.7), oklch(0.65 0.25 25 / 0.7), transparent)" }} />
          {steps.map((s, i) => (
            <Reveal key={s.n} delay={i * 150}>
              <div className="relative glass rounded-2xl p-6 hover-lift">
                <span className="absolute -top-3 -right-3 inline-flex h-10 w-10 items-center justify-center rounded-full gradient-brand text-white font-display font-bold text-sm glow-mix">{s.n}</span>
                <h3 className="font-display text-lg font-bold mb-1">{s.t}</h3>
                <p className="text-sm text-muted-foreground">{s.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Technologies */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <Reveal className="text-center mb-10 max-w-2xl mx-auto">
          <h2 className="font-display text-4xl sm:text-5xl font-bold">Technologies</h2>
          <p className="mt-4 text-muted-foreground">
            At TRIOCTO, we use the latest software, platforms, and digital tools to deliver high-end and technically advanced solutions for modern businesses.
          </p>
        </Reveal>
        <div className="flex flex-wrap justify-center gap-3">
          {techs.map((t, i) => (
            <Reveal key={t} delay={i * 40}>
              <span className="glass rounded-full px-5 py-2.5 text-sm font-medium hover-lift inline-block" style={{ borderColor: i % 2 === 0 ? "oklch(0.65 0.22 255 / 0.3)" : "oklch(0.65 0.25 25 / 0.3)" }}>
                {t}
              </span>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Testimonials preview */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <Reveal className="text-center mb-12">
          <h2 className="font-display text-4xl sm:text-5xl font-bold">What Our Clients Say</h2>
        </Reveal>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 100}>
              <div className="glass rounded-2xl p-6 hover-lift h-full">
                <div className="flex gap-1 mb-3 text-[var(--neon-blue)]">
                  {Array.from({ length: 5 }).map((_, k) => <Star key={k} className="h-4 w-4 fill-current" />)}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">"{t.text}"</p>
                <p className="mt-4 font-display font-semibold">{t.name}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <div className="mt-10 text-center">
          <Link to="/testimonials" className="text-sm font-semibold text-[var(--neon-blue)] hover:underline">View all reviews →</Link>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-20">
        <div className="relative glass-strong rounded-3xl p-12 sm:p-16 text-center overflow-hidden">
          <TechBackground />
          <h2 className="relative font-display text-3xl sm:text-5xl font-bold mb-4">
            Contact Us For Further <span className="gradient-text">Information!</span>
          </h2>
          <p className="relative text-muted-foreground max-w-2xl mx-auto mb-7">
            Take the first step towards an impressive online presence. Contact us now and let's build something powerful together.
          </p>
          <Link to="/contact" className="relative inline-flex rounded-full gradient-brand px-7 py-3 text-sm font-semibold text-white animate-pulse-glow">
            Submit Message
          </Link>
        </div>
      </section>
    </div>
  );
}
