import { createFileRoute, Link } from "@tanstack/react-router";
import { Phone, Target, Eye, Heart, Award } from "lucide-react";
import { TechBackground } from "@/components/TechBackground";
import { Reveal } from "@/components/Reveal";
import { useQuote } from "@/components/QuoteProvider";
import { BRAND } from "@/data/brand";

export const Route = createFileRoute("/about-us")({
  head: () => ({
    meta: [
      { title: "About TRIOCTO — Our Story, Mission and Vision" },
      { name: "description", content: "TRIOCTO is a premium digital agency founded in 2026 by Aakash Gandhi, Ketan Chaudhari, and Sahas Thakery, building cutting-edge web and growth solutions." },
      { property: "og:title", content: "About TRIOCTO" },
      { property: "og:description", content: "Founded by Aakash Gandhi, Ketan Chaudhari & Sahas Thakery. Premium digital technology agency." },
      { property: "og:url", content: "/about-us" },
    ],
    links: [{ rel: "canonical", href: "/about-us" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  const { open } = useQuote();
  const sections = [
    { icon: Award, title: "Our Story", body: `Founded in ${BRAND.founded} by Aakash Gandhi, Ketan Chaudhari, and Sahas Thakery, TRIOCTO was born from a shared belief that great technology should be accessible, beautiful, and built around the customer.` },
    { icon: Target, title: "Mission", body: "To help businesses thrive in the digital world through innovative technology, beautiful design and results-driven strategy." },
    { icon: Eye, title: "Vision", body: "To be the most trusted partner for ambitious brands building their digital future — from first website to enterprise platform." },
    { icon: Heart, title: "Philosophy", body: "Craft over speed. Honesty over hype. Results over noise. Every project we ship is something we'd be proud to put our name on." },
  ];
  const why = ["Prioritizing your goals and vision", "Proven track record with successful projects", "Commitment to quality and innovation", "Affordable and scalable solutions", "Dedicated customer support", "Fast project delivery"];

  return (
    <div>
      <section className="relative pt-20 pb-24 overflow-hidden">
        <TechBackground variant="hero" />
        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-xs tracking-[0.3em] text-[var(--neon-blue)] uppercase mb-3">About Us</p>
            <h1 className="font-display text-5xl sm:text-7xl font-bold">
              About <span className="gradient-text">TRIOCTO</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
              We provide the best digital design and technology solutions in town. Founded by {BRAND.founders} in {BRAND.founded}, TRIOCTO is dedicated to helping businesses thrive in the digital world through innovative technology and result-driven strategies.
            </p>
            <p className="mt-5 text-muted-foreground leading-relaxed">
              At TRIOCTO, we are a passionate team of Digital Marketing and Website Development experts committed to creating cutting-edge, custom web solutions that elevate your online presence and drive business success.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {sections.map((s, i) => (
            <Reveal key={s.title} delay={i * 100}>
              <div className="glass rounded-2xl p-7 hover-lift h-full">
                <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl gradient-brand glow-blue mb-4">
                  <s.icon className="h-5 w-5 text-white" />
                </div>
                <h2 className="font-display text-2xl font-bold mb-2">{s.title}</h2>
                <p className="text-muted-foreground leading-relaxed">{s.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <Reveal className="text-center mb-10">
          <h2 className="font-display text-4xl sm:text-5xl font-bold">
            Why Choose <span className="gradient-text">TRIOCTO</span>
          </h2>
        </Reveal>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {why.map((w, i) => (
            <Reveal key={w} delay={i * 80}>
              <div className="glass rounded-xl p-5 flex items-start gap-3 hover-lift">
                <span className="h-6 w-6 rounded-full gradient-brand shrink-0 mt-0.5" />
                <span className="text-sm">{w}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="relative glass-strong rounded-3xl p-10 sm:p-14 text-center overflow-hidden">
          <TechBackground />
          <p className="relative text-xs tracking-[0.3em] text-[var(--neon-red)] uppercase mb-2">Call Anytime</p>
          <h2 className="relative font-display text-4xl sm:text-5xl font-bold mb-6">
            <span className="gradient-text">{BRAND.phone}</span>
          </h2>
          <div className="relative flex flex-wrap justify-center gap-3">
            <button onClick={() => open()} className="rounded-full gradient-brand px-7 py-3 text-sm font-semibold text-white animate-pulse-glow">GET FREE QUOTE</button>
            <a href={`tel:${BRAND.phoneRaw}`} className="rounded-full glass px-7 py-3 text-sm font-semibold inline-flex items-center gap-2 hover:bg-white/10 transition-colors">
              <Phone className="h-4 w-4" /> CALL NOW
            </a>
            <Link to="/contact" className="rounded-full glass px-7 py-3 text-sm font-semibold hover:bg-white/10 transition-colors">Contact Us</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
