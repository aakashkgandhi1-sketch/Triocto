import { createFileRoute, Link } from "@tanstack/react-router";
import { Calendar, ArrowRight } from "lucide-react";
import { TechBackground } from "@/components/TechBackground";
import { Reveal } from "@/components/Reveal";
import { blogPosts } from "@/data/blog";

export const Route = createFileRoute("/blog/")({
  head: () => ({
    meta: [
      { title: "Blog — TRIOCTO Insights on Web, SEO and Design" },
      { name: "description", content: "Latest insights from TRIOCTO on SEO, UI/UX, hosting, mobile apps and web development trends." },
      { property: "og:title", content: "TRIOCTO Blog" },
      { property: "og:description", content: "Checkout our latest blog & insights." },
      { property: "og:url", content: "/blog" },
    ],
    links: [{ rel: "canonical", href: "/blog" }],
  }),
  component: BlogIndex,
});

function BlogIndex() {
  return (
    <div>
      <section className="relative pt-20 pb-16 overflow-hidden">
        <TechBackground variant="hero" />
        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-xs tracking-[0.3em] text-[var(--neon-blue)] uppercase mb-3">Blog & Insights</p>
            <h1 className="font-display text-5xl sm:text-6xl font-bold">
              Checkout Our Latest <span className="gradient-text">Blog & Insights</span>
            </h1>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {blogPosts.map((p, i) => (
            <Reveal key={p.slug} delay={i * 80}>
              <Link
                to="/blog/$slug"
                params={{ slug: p.slug }}
                className="block glass rounded-2xl overflow-hidden hover-lift group h-full"
              >
                <div className="relative aspect-video gradient-brand opacity-90 flex items-center justify-center overflow-hidden">
                  <div className="absolute inset-0 tech-grid opacity-30" />
                  <span className="relative font-display text-5xl font-bold text-white/90">{p.category.charAt(0)}</span>
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                    <span className="rounded-full glass px-2.5 py-0.5">{p.category}</span>
                    <span className="inline-flex items-center gap-1"><Calendar className="h-3 w-3" /> {p.date}</span>
                  </div>
                  <h2 className="font-display text-lg font-bold mb-2 group-hover:gradient-text transition-all">{p.title}</h2>
                  <p className="text-sm text-muted-foreground line-clamp-3">{p.excerpt}</p>
                  <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-[var(--neon-blue)]">
                    Read more <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}
