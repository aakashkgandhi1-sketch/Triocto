import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const LeadSchema = z.object({
  source: z.enum(["contact", "quote", "email"]),
  name: z.string().trim().min(1).max(100),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().max(30).optional().default(""),
  service: z.string().trim().max(150).optional().default(""),
  budget: z.string().trim().max(60).optional().default(""),
  message: z.string().trim().max(2000).optional().default(""),
  pageUrl: z.string().trim().max(500).optional().default(""),
});

const SUBJECTS: Record<string, string> = {
  contact: "New Contact Form Submission - TRIOCTO",
  quote: "New Quote Request - TRIOCTO",
  email: "New Email Inquiry - TRIOCTO",
};

export const submitLead = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => LeadSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { error: dbError } = await supabaseAdmin.from("leads").insert({
      source: data.source,
      name: data.name,
      email: data.email,
      phone: data.phone || null,
      service: data.service || null,
      budget: data.budget || null,
      message: data.message || null,
    });

    if (dbError) {
      console.error("[submitLead] db insert failed:", dbError);
      throw new Error("Failed to save your submission. Please try again.");
    }

    const formId = process.env.FORMSPREE_FORM_ID;
    if (!formId) {
      console.warn("[submitLead] FORMSPREE_FORM_ID not set — saved to DB only.");
      return { ok: true, emailed: false };
    }

    const subject = SUBJECTS[data.source] ?? "New Submission - TRIOCTO";
    const submittedAt = new Date().toLocaleString("en-IN", {
      timeZone: "Asia/Kolkata",
      dateStyle: "full",
      timeStyle: "short",
    });

    const payload: Record<string, string> = {
      _subject: subject,
      _replyto: data.email,
      Name: data.name,
      Email: data.email,
      Phone: data.phone || "—",
      Service: data.service || "—",
      Message: data.message || "—",
      "Submitted At": submittedAt,
      "Page URL": data.pageUrl || "—",
      "Form Type": data.source,
    };
    if (data.source === "quote") payload.Budget = data.budget || "—";

    try {
      const res = await fetch(`https://formspree.io/f/${formId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const body = await res.text();
        console.error("[submitLead] formspree error:", res.status, body);
        return { ok: true, emailed: false };
      }
      return { ok: true, emailed: true };
    } catch (err) {
      console.error("[submitLead] formspree exception:", err);
      return { ok: true, emailed: false };
    }
  });
