import { Link } from "@tanstack/react-router";
import { Mail, Phone, MapPin } from "lucide-react";
import { SocialLinks } from "./SocialLinks";
import { Logo } from "./Logo";
import { BRAND } from "@/data/brand";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { toast } from "sonner";

const links = [
  { to: "/about-us", label: "About Us" },
  { to: "/services", label: "Services" },
  { to: "/portfolio", label: "Portfolio" },
  { to: "/pricing", label: "Pricing" },
  { to: "/testimonials", label: "Testimonials" },
  { to: "/blog", label: "Blog" },
  { to: "/contact", label: "Contact Us" },
] as const;

export function Footer() {
  return (
    <footer className="relative mt-24 border-t border-white/10 bg-[oklch(0.1_0.04_265)] overflow-hidden">
      <div className="absolute inset-0 radial-glow opacity-50" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <Logo />
            <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
              At TRIOCTO, we are a passionate team of Digital Marketing and Web Development experts committed to creating cutting-edge, custom solutions that elevate your online presence and drive business success.
            </p>
            <div className="mt-5">
              <SocialLinks />
            </div>
          </div>
          <div>
            <h4 className="font-display font-semibold mb-4">Useful Links</h4>
            <ul className="space-y-2 text-sm">
              {links.map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="text-muted-foreground hover:text-foreground hover:translate-x-1 inline-block transition-all">
                    → {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-display font-semibold mb-4">Get in Touch</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex gap-2"><Phone className="h-4 w-4 mt-0.5 text-[var(--neon-blue)]" /> <a href={`tel:${BRAND.phoneRaw}`} className="hover:text-foreground">{BRAND.phone}</a></li>
              <li className="flex gap-2"><Mail className="h-4 w-4 mt-0.5 text-[var(--neon-red)]" /> <a href={`mailto:${BRAND.email}`} className="hover:text-foreground">{BRAND.email}</a></li>
              <li className="flex gap-2"><MapPin className="h-4 w-4 mt-0.5 text-[var(--neon-blue)] shrink-0" /> <span>{BRAND.address}</span></li>
            </ul>
          </div>
          <div>
            <h4 className="font-display font-semibold mb-4">Newsletter</h4>
            <p className="text-sm text-muted-foreground mb-3">
              Stay up-to-date with the latest news and web development trends by subscribing to our newsletter.
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                (e.target as HTMLFormElement).reset();
                toast.success("Subscribed! Thank you.");
              }}
              className="flex flex-col gap-2"
            >
              <Input type="email" required placeholder="Your email" className="bg-white/5 border-white/10" />
              <Button type="submit" className="gradient-brand text-white">Subscribe</Button>
            </form>
          </div>
        </div>
        <div className="mt-12 pt-6 border-t border-white/10 text-center text-xs text-muted-foreground">
          Copyright © 2026 TRIOCTO | All Rights Reserved
        </div>
      </div>
    </footer>
  );
}
