import { createFileRoute } from "@tanstack/react-router";
import { TechBackground } from "@/components/TechBackground";
import { Reveal } from "@/components/Reveal";
import { ServiceCard } from "@/components/ServiceCard";
import { services } from "@/data/services";

export const Route = createFileRoute("/services/")({
  head: () => ({
    meta: [
      { title: "Services — TRIOCTO Digital Technology Agency" },
      { name: "description", content: "Web design, mobile apps, ecommerce, SEO, digital marketing, hosting and IT services from TRIOCTO." },
      { property: "og:title", content: "TRIOCTO Services" },
      { property: "og:description", content: "Premium digital services that elevate your brand." },
      { property: "og:url", content: "/services" },
    ],
    links: [{ rel: "canonical", href: "/services" }],
  }),
  component: ServicesIndex,
});

function ServicesIndex() {
  return (
    <div>
      <section className="relative pt-20 pb-20 overflow-hidden">
        <TechBackground variant="hero" />
        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-xs tracking-[0.3em] text-[var(--neon-blue)] uppercase mb-3">Best Website Design Service Provider</p>
            <h1 className="font-display text-5xl sm:text-7xl font-bold">
              Elevate Your Brand With <span className="gradient-text">TRIOCTO</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground">
              Ten premium services. One trusted partner. Pick what you need — or combine them for end-to-end digital excellence.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s, i) => (
            <Reveal key={s.slug} delay={i * 70}>
              <ServiceCard service={s} detailed />
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}
