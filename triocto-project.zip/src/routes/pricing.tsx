import { createFileRoute } from "@tanstack/react-router";
import { Check, Sparkles } from "lucide-react";
import { TechBackground } from "@/components/TechBackground";
import { Reveal } from "@/components/Reveal";
import { useQuote } from "@/components/QuoteProvider";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — TRIOCTO Flexible Digital Packages" },
      { name: "description", content: "Flexible digital packages from TRIOCTO — starter websites to custom enterprise solutions. Request a tailored quote." },
      { property: "og:title", content: "TRIOCTO Pricing" },
      { property: "og:description", content: "Flexible digital solutions for every business." },
      { property: "og:url", content: "/pricing" },
    ],
    links: [{ rel: "canonical", href: "/pricing" }],
  }),
  component: PricingPage,
});

const tiers = [
  { name: "Starter Website Package", tagline: "Perfect for new businesses", features: ["Business website", "Responsive design", "Basic SEO setup", "Contact form", "Mobile optimization"], highlight: false },
  { name: "Business Growth Package", tagline: "Scale your online presence", features: ["Advanced website", "SEO setup", "Social media integration", "Analytics setup", "Speed optimization"], highlight: true },
  { name: "Ecommerce Package", tagline: "Sell online with confidence", features: ["Online store", "Product management", "Secure payment gateway", "Order management", "Admin panel"], highlight: false },
  { name: "Custom Enterprise Solution", tagline: "Built around your business", features: ["Custom web application", "Advanced integrations", "Scalable architecture", "Maintenance support", "Dedicated consultation"], highlight: false },
];

function PricingPage() {
  const { open } = useQuote();
  return (
    <div>
      <section className="relative pt-20 pb-16 overflow-hidden">
        <TechBackground variant="hero" />
        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-xs tracking-[0.3em] text-[var(--neon-blue)] uppercase mb-3">Pricing</p>
            <h1 className="font-display text-5xl sm:text-6xl font-bold">
              Flexible Digital Solutions for <span className="gradient-text">Every Business</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground">
              Every project is unique. We tailor each package to your goals — request a free quote to get pricing for your exact needs.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {tiers.map((t, i) => (
            <Reveal key={t.name} delay={i * 100}>
              <div className={`relative glass rounded-2xl p-7 hover-lift h-full flex flex-col ${t.highlight ? "glass-strong glow-mix" : ""}`}>
                {t.highlight && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 inline-flex items-center gap-1 rounded-full gradient-brand px-3 py-1 text-[10px] uppercase tracking-wider font-bold text-white">
                    <Sparkles className="h-3 w-3" /> Most Popular
                  </span>
                )}
                <h3 className="font-display text-xl font-bold">{t.name}</h3>
                <p className="text-sm text-muted-foreground mt-1">{t.tagline}</p>
                <div className="my-5 h-px gradient-brand opacity-50" />
                <ul className="space-y-2.5 mb-7 flex-1">
                  {t.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check className="h-4 w-4 text-[var(--neon-blue)] mt-0.5 shrink-0" /> {f}
                    </li>
                  ))}
                </ul>
                <button onClick={() => open(t.name)} className={`w-full rounded-full px-5 py-3 text-sm font-semibold ${t.highlight ? "gradient-brand text-white animate-pulse-glow" : "glass hover:bg-white/10 transition-colors"}`}>
                  Request Quote
                </button>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}
