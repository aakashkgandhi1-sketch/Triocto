import { useEffect, useRef, useState } from "react";

export function Counter({ to, suffix = "", duration = 1800, decimals = 0 }: { to: number; suffix?: string; duration?: number; decimals?: number }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting && !started.current) {
            started.current = true;
            const start = performance.now();
            const factor = Math.pow(10, decimals);
            const tick = (now: number) => {
              const p = Math.min(1, (now - start) / duration);
              const eased = 1 - Math.pow(1 - p, 3);
              setVal(Math.round(to * eased * factor) / factor);
              if (p < 1) requestAnimationFrame(tick);
            };
            requestAnimationFrame(tick);
          }
        });
      },
      { threshold: 0.3 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [to, duration, decimals]);

  const display = decimals > 0 ? val.toFixed(decimals) : String(val);

  return (
    <span ref={ref} className="font-display text-5xl sm:text-6xl font-bold gradient-text">
      {display}
      {suffix}
    </span>
  );
}
