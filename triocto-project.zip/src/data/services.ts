export type Service = {
  slug: string;
  title: string;
  short: string;
  heading: string;
  description: string;
  features: string[];
  icon: string;
};

export const services: Service[] = [
  {
    slug: "website-design-development",
    title: "Website Design & Development",
    short: "Pixel-perfect, conversion-driven websites tailored to your brand identity.",
    heading: "Unveiling Your Digital Identity",
    description:
      "With TRIOCTO as your partner, your website becomes more than just an online presence. It becomes a powerful tool for connecting with your audience, driving growth, and achieving digital success.",
    features: ["Customized Designs", "Responsive Design", "E-Commerce Solutions", "Interactive Elements"],
    icon: "Globe",
  },
  {
    slug: "mobile-app-development",
    title: "Mobile App Development",
    short: "Native and cross-platform mobile apps for iOS and Android.",
    heading: "Driving Innovation with TRIOCTO Mobile App Development",
    description:
      "TRIOCTO creates functional and user-friendly mobile applications for Android, iOS, and cross-platform use.",
    features: ["Custom App Solutions", "Cross-Platform Development", "App Testing", "Quality Assurance"],
    icon: "Smartphone",
  },
  {
    slug: "web-application-development",
    title: "Web Application Development",
    short: "Scalable, secure web applications engineered for performance.",
    heading: "Building Functional and Engaging Web Applications",
    description:
      "TRIOCTO builds dynamic, interactive, and scalable web applications for modern businesses.",
    features: ["Custom Solutions", "Scalability", "Performance Optimization", "User-Centric Design"],
    icon: "Layers",
  },
  {
    slug: "ecommerce-website-development",
    title: "Ecommerce Website Development",
    short: "High-converting online stores with secure payments and smooth UX.",
    heading: "Elevate Your Online Business with TRIOCTO Ecommerce Website Development Service",
    description:
      "TRIOCTO creates secure and user-friendly ecommerce platforms that help businesses sell products and services online.",
    features: ["User-Centric Design", "Responsive Layout", "Secure Payment Gateways", "Streamlined Checkout"],
    icon: "ShoppingCart",
  },
  {
    slug: "web-maintenance",
    title: "Web Maintenance",
    short: "Keep your website fast, secure and always up-to-date.",
    heading: "The Importance of Web Maintenance",
    description:
      "TRIOCTO keeps websites secure, updated, fast, responsive, and reliable through regular monitoring and optimization.",
    features: ["Regular Updates", "Bug Fixes", "Content Updates", "Analytics Integration"],
    icon: "Wrench",
  },
  {
    slug: "wordpress-maintenance",
    title: "WordPress Website Maintenance",
    short: "Expert WordPress care — updates, backups and 24/7 monitoring.",
    heading: "Overview of the Service",
    description:
      "TRIOCTO helps WordPress websites stay secure, updated, optimized, backed up, and fully functional.",
    features: ["Regular Updates", "Backup Solutions", "24/7 Monitoring", "Technical Support"],
    icon: "Settings",
  },
  {
    slug: "seo-sem",
    title: "SEO & SEM",
    short: "Rank higher, get found, and convert traffic into customers.",
    heading: "Navigating the SEO & SEM Landscape with TRIOCTO",
    description:
      "TRIOCTO improves search visibility through SEO strategies and drives targeted traffic through paid advertising campaigns.",
    features: ["Technical SEO", "Link Building", "Keyword Targeting", "Ad Creatives"],
    icon: "Search",
  },
  {
    slug: "digital-marketing-smo",
    title: "Digital Marketing / SMO",
    short: "Grow your brand with data-driven social media and paid campaigns.",
    heading: "Harnessing the Potential of Social Media with TRIOCTO Digital Marketing Service",
    description:
      "TRIOCTO helps brands grow online using social media, content, advertising, engagement, and performance marketing strategies.",
    features: ["Analytics Reporting", "Strategy Consultation", "Social Media Marketing", "Paid Advertising"],
    icon: "Megaphone",
  },
  {
    slug: "domain-hosting",
    title: "Domain & Hosting Services",
    short: "Reliable hosting and domain solutions with rock-solid uptime.",
    heading: "Securing Your Digital Identity with TRIOCTO Domain & Hosting Solutions",
    description:
      "TRIOCTO provides domain registration, hosting, managed hosting, privacy, uptime, and scalable hosting support.",
    features: ["Domain Privacy", "Domain Transfer", "Shared Hosting", "VPS Hosting"],
    icon: "Server",
  },
  {
    slug: "it-services",
    title: "IT Services",
    short: "Friendly, expert IT support for homes and businesses, anytime.",
    heading: "IT Services and Support by TRIOCTO Experts",
    description:
      "TRIOCTO makes digital life easier through IT support, troubleshooting, device support, network support, and business technology assistance.",
    features: ["Tech Support", "Network Setup", "Device Support", "Business IT"],
    icon: "Cpu",
  },
  {
    slug: "ai-marketing",
    title: "AI Marketing",
    short: "Use AI to target smarter, automate campaigns and grow conversions.",
    heading: "AI Marketing Solutions for the Future of Business Growth",
    description:
      "AI Marketing helps businesses use artificial intelligence to improve campaigns, understand customers, automate marketing tasks, and increase conversions. TRIOCTO provides AI-powered marketing solutions including customer targeting, content automation, campaign optimization, chatbot strategy, predictive analytics, lead generation automation, and performance tracking.",
    features: [
      "AI-powered campaign strategy",
      "Automated content ideas",
      "Smart customer targeting",
      "Predictive analytics",
      "AI chatbot marketing",
      "Lead generation automation",
      "Ad performance optimization",
      "Marketing data insights",
    ],
    icon: "Brain",
  },
];

export const getService = (slug: string) => services.find((s) => s.slug === slug);
