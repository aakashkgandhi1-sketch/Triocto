import { Link } from "@tanstack/react-router";
import logoAsset from "@/assets/triocto-logo-2026.jpg.asset.json";

interface LogoProps {
  className?: string;
  placement?: "header" | "footer";
}

export function Logo({ className = "", placement = "footer" }: LogoProps) {
  const sizeClass = placement === "header"
    ? "h-16 w-16 sm:h-[4.5rem] sm:w-[4.5rem] lg:h-24 lg:w-24"
    : "h-20 w-20";

  return (
    <Link
      to="/"
      className={`group inline-flex shrink-0 items-center ${className}`}
      aria-label="TRIOCTO home"
    >
      <img
        src={logoAsset.url}
        alt="TRIOCTO IT Solutions — Accelerate, Automate, Achieve"
        width={1024}
        height={1024}
        className={`${sizeClass} block rounded-full object-contain transition-[transform,filter] duration-300 group-hover:scale-[1.03] logo-glow group-hover:logo-glow-hover`}
        loading="eager"
        decoding="async"
        draggable={false}
      />
    </Link>
  );
}
