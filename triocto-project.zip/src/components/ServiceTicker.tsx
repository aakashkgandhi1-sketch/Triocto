export function ServiceTicker() {
  const items = [
    "Website Design & Development",
    "Mobile App Development",
    "Web Application Development",
    "Ecommerce Websites",
    "Digital Marketing",
    "AI Marketing",
    "SEO & SEM",
    "SMO",
    "Web Maintenance",
    "WordPress Maintenance",

    "Domain & Hosting",
    "IT Services",
  ];
  const row = [...items, ...items];
  return (
    <section className="relative py-10">
      <div className="text-center mb-6">
        <p className="text-xs tracking-[0.3em] text-muted-foreground uppercase">Our Digital Solutions</p>
      </div>
      <div className="relative glass border-y border-white/10 overflow-hidden py-5">
        <div className="absolute top-0 left-0 right-0 h-px" style={{ background: "linear-gradient(90deg, transparent, oklch(0.7 0.22 250 / 0.8), transparent)" }} />
        <div className="absolute bottom-0 left-0 right-0 h-px" style={{ background: "linear-gradient(90deg, transparent, oklch(0.7 0.25 25 / 0.8), transparent)" }} />
        <div className="flex w-max animate-ticker gap-12">
          {row.map((t, i) => (
            <span
              key={i}
              className="font-display text-lg sm:text-xl font-semibold whitespace-nowrap"
              style={{
                color: i % 2 === 0 ? "oklch(0.78 0.18 250)" : "oklch(0.75 0.2 25)",
                textShadow:
                  i % 2 === 0
                    ? "0 0 18px oklch(0.65 0.22 250 / 0.6)"
                    : "0 0 18px oklch(0.65 0.25 25 / 0.6)",
              }}
            >
              ✦ {t}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
