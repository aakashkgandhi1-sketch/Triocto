import { createFileRoute, notFound } from "@tanstack/react-router";
import { ServiceDetailLayout } from "@/components/ServiceDetailLayout";
import { getService, services } from "@/data/services";

export const Route = createFileRoute("/services/$slug")({
  loader: ({ params }) => {
    const service = getService(params.slug);
    if (!service) throw notFound();
    return { service };
  },
  head: ({ loaderData }) => {
    const s = loaderData?.service;
    if (!s) return {};
    return {
      meta: [
        { title: `${s.title} — TRIOCTO` },
        { name: "description", content: s.short },
        { property: "og:title", content: `${s.title} — TRIOCTO` },
        { property: "og:description", content: s.short },
        { property: "og:url", content: `/services/${s.slug}` },
      ],
      links: [{ rel: "canonical", href: `/services/${s.slug}` }],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-4 py-32 text-center">
      <h1 className="font-display text-4xl font-bold mb-4">Service not found</h1>
      <p className="text-muted-foreground">Available services: {services.map((s) => s.title).join(", ")}</p>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="mx-auto max-w-3xl px-4 py-32 text-center">
      <h1 className="font-display text-3xl font-bold">Couldn't load service</h1>
      <p className="text-muted-foreground mt-2">{error.message}</p>
    </div>
  ),
  component: ServicePage,
});

function ServicePage() {
  const { service } = Route.useLoaderData();
  return <ServiceDetailLayout service={service} />;
}
