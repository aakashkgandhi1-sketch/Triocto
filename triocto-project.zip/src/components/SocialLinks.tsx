import { Facebook, Instagram, Linkedin } from "lucide-react";
import { BRAND } from "@/data/brand";

const items = [
  { Icon: Facebook, href: BRAND.socials.facebook, label: "Facebook", color: "blue" as const },
  { Icon: Instagram, href: BRAND.socials.instagram, label: "Instagram", color: "red" as const },
  { Icon: Linkedin, href: BRAND.socials.linkedin, label: "LinkedIn", color: "blue" as const },
];

export function SocialLinks({ size = "md" }: { size?: "md" | "lg" }) {
  const dim = size === "lg" ? "h-12 w-12" : "h-10 w-10";
  const icon = size === "lg" ? "h-5 w-5" : "h-4 w-4";
  return (
    <div className="flex gap-3">
      {items.map(({ Icon, href, label, color }) => (
        <a
          key={label}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={label}
          className={`group ${dim} rounded-full glass flex items-center justify-center transition-all duration-300 hover:-translate-y-0.5 hover:scale-110`}
          style={{
            boxShadow: "0 0 0 transparent",
          }}
          onMouseEnter={(e) => {
            const c = color === "blue" ? "oklch(0.7 0.22 250 / 0.9)" : "oklch(0.65 0.25 25 / 0.9)";
            e.currentTarget.style.boxShadow = `0 0 22px ${c}, 0 0 6px ${c}`;
            e.currentTarget.style.borderColor = c;
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.boxShadow = "0 0 0 transparent";
            e.currentTarget.style.borderColor = "";
          }}
        >
          <Icon className={`${icon} group-hover:text-white transition-colors`} />
        </a>
      ))}
    </div>
  );
}
