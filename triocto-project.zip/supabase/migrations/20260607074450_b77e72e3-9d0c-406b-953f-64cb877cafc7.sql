-- Revoke any direct Data API access; only service_role (server) should touch leads.
REVOKE ALL ON public.leads FROM anon, authenticated;
GRANT ALL ON public.leads TO service_role;

-- Explicit deny policies so RLS has policies defined (satisfies linter) and any
-- direct PostgREST access from anon/authenticated is blocked. The server uses
-- the service_role key which bypasses RLS entirely.
DROP POLICY IF EXISTS "Deny all access to anon" ON public.leads;
DROP POLICY IF EXISTS "Deny all access to authenticated" ON public.leads;

CREATE POLICY "Deny all access to anon"
  ON public.leads
  AS RESTRICTIVE
  FOR ALL
  TO anon
  USING (false)
  WITH CHECK (false);

CREATE POLICY "Deny all access to authenticated"
  ON public.leads
  AS RESTRICTIVE
  FOR ALL
  TO authenticated
  USING (false)
  WITH CHECK (false);
