import { createFileRoute } from "@tanstack/react-router";
import { Phone, Mail, MapPin } from "lucide-react";
import { TechBackground } from "@/components/TechBackground";
import { Reveal } from "@/components/Reveal";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { services } from "@/data/services";
import { BRAND } from "@/data/brand";
import { SocialLinks } from "@/components/SocialLinks";
import { submitLead } from "@/lib/leads.functions";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact TRIOCTO — Schedule a Consultation" },
      { name: "description", content: "Get in touch with TRIOCTO for digital marketing, web design and development. Schedule a free consultation today." },
      { property: "og:title", content: "Contact TRIOCTO" },
      { property: "og:description", content: "Get in touch with us — we'd love to hear from you." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [busy, setBusy] = useState(false);
  const submit = useServerFn(submitLead);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    setBusy(true);
    try {
      await submit({
        data: {
          source: "contact",
          name: String(fd.get("name") ?? ""),
          email: String(fd.get("email") ?? ""),
          phone: String(fd.get("phone") ?? ""),
          service: String(fd.get("service") ?? ""),
          message: String(fd.get("message") ?? ""),
          pageUrl: typeof window !== "undefined" ? window.location.href : "",
        },
      });

      toast.success("Thank you! TRIOCTO will contact you shortly.");
      form.reset();
    } catch (err: any) {
      toast.error(err?.message ?? "Something went wrong. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <section className="relative pt-20 pb-16 overflow-hidden">
        <TechBackground variant="hero" />
        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-xs tracking-[0.3em] text-[var(--neon-blue)] uppercase mb-3">Need Any Help?</p>
            <h1 className="font-display text-5xl sm:text-7xl font-bold">
              Get in touch <span className="gradient-text">with us</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
              Thank you for considering TRIOCTO for your Digital Marketing and Website Development needs. We would love to hear from you and discuss how we can help elevate your online presence and achieve your digital objectives.
            </p>
            <div className="mt-7 flex justify-center">
              <SocialLinks size="lg" />
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-2 gap-8">
          <Reveal>
            <div className="space-y-4">
              <div className="glass rounded-2xl p-6 hover-lift">
                <div className="flex items-start gap-4">
                  <div className="h-11 w-11 rounded-xl gradient-brand glow-blue flex items-center justify-center shrink-0">
                    <Phone className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-widest text-muted-foreground">Phone</p>
                    <a href={`tel:${BRAND.phoneRaw}`} className="font-display text-lg font-semibold hover:gradient-text transition-all block">{BRAND.phone}</a>
                    <a href={`tel:${BRAND.phone2.replace(/\s/g, "")}`} className="text-sm text-muted-foreground">{BRAND.phone2}</a>
                  </div>
                </div>
              </div>
              <div className="glass rounded-2xl p-6 hover-lift">
                <div className="flex items-start gap-4">
                  <div className="h-11 w-11 rounded-xl gradient-brand glow-red flex items-center justify-center shrink-0">
                    <Mail className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-widest text-muted-foreground">Email</p>
                    <a href={`mailto:${BRAND.email}`} className="font-display text-lg font-semibold hover:gradient-text transition-all">{BRAND.email}</a>
                  </div>
                </div>
              </div>
              <div className="glass rounded-2xl p-6 hover-lift">
                <div className="flex items-start gap-4">
                  <div className="h-11 w-11 rounded-xl gradient-brand glow-mix flex items-center justify-center shrink-0">
                    <MapPin className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-widest text-muted-foreground">Address</p>
                    <p className="font-medium leading-relaxed">{BRAND.address}</p>
                  </div>
                </div>
              </div>
              <div className="glass rounded-2xl p-6">
                <p className="text-xs uppercase tracking-widest text-muted-foreground mb-3">Follow Us</p>
                <SocialLinks size="lg" />
              </div>
            </div>
          </Reveal>

          <Reveal delay={150}>
            <div className="glass-strong rounded-2xl p-7 sm:p-8">
              <p className="text-xs tracking-[0.3em] text-[var(--neon-red)] uppercase mb-2">Schedule a Consultation</p>
              <h2 className="font-display text-2xl sm:text-3xl font-bold mb-6">
                Let's Start A New Project or <span className="gradient-text">Work Together!</span>
              </h2>
              <form onSubmit={onSubmit} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="c-name">Name</Label>
                    <Input id="c-name" name="name" required maxLength={100} className="bg-white/5 border-white/10" />
                  </div>
                  <div>
                    <Label htmlFor="c-email">Email</Label>
                    <Input id="c-email" name="email" type="email" required maxLength={255} className="bg-white/5 border-white/10" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="c-phone">Phone</Label>
                  <Input id="c-phone" name="phone" type="tel" required maxLength={20} className="bg-white/5 border-white/10" />
                </div>
                <div>
                  <Label>Select Services</Label>
                  <Select name="service" defaultValue={services[0].title}>
                    <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {services.map((s) => (
                        <SelectItem key={s.slug} value={s.title}>{s.title}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="c-msg">Message</Label>
                  <Textarea id="c-msg" name="message" rows={4} required maxLength={1000} className="bg-white/5 border-white/10" />
                </div>
                <Button type="submit" disabled={busy} className="w-full gradient-brand text-white h-11 font-semibold animate-pulse-glow">
                  {busy ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
