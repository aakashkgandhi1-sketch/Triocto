export function TechBackground({ variant = "default" }: { variant?: "default" | "hero" }) {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden -z-10">
      <div className="absolute inset-0 radial-glow" />
      <div className="absolute inset-0 tech-grid opacity-60 animate-grid" />
      {/* Neon moving lines */}
      <div className="absolute left-0 right-0 top-1/4 h-px overflow-hidden">
        <div
          className="h-full w-full"
          style={{
            background:
              "linear-gradient(90deg, transparent, oklch(0.7 0.22 250 / 0.9), transparent)",
            animation: "neon-line 7s linear infinite",
          }}
        />
      </div>
      <div className="absolute left-0 right-0 bottom-1/3 h-px overflow-hidden">
        <div
          className="h-full w-full"
          style={{
            background:
              "linear-gradient(90deg, transparent, oklch(0.65 0.25 25 / 0.9), transparent)",
            animation: "neon-line 9s linear 2s infinite",
          }}
        />
      </div>
      {/* Particles */}
      {variant === "hero" &&
        Array.from({ length: 18 }).map((_, i) => (
          <span
            key={i}
            className="absolute block rounded-full"
            style={{
              left: `${(i * 53) % 100}%`,
              width: `${4 + (i % 4)}px`,
              height: `${4 + (i % 4)}px`,
              background:
                i % 2 === 0
                  ? "oklch(0.75 0.22 250 / 0.8)"
                  : "oklch(0.7 0.25 25 / 0.7)",
              boxShadow:
                i % 2 === 0
                  ? "0 0 12px oklch(0.7 0.22 250 / 0.9)"
                  : "0 0 12px oklch(0.65 0.25 25 / 0.9)",
              animation: `float-up ${10 + (i % 6) * 2}s linear ${i * 0.4}s infinite`,
            }}
          />
        ))}
    </div>
  );
}
