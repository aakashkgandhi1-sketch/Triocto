import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { TechBackground } from "@/components/TechBackground";
import { Reveal } from "@/components/Reveal";
import { useQuote } from "@/components/QuoteProvider";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import * as Icons from "lucide-react";

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: [
      { title: "Portfolio — TRIOCTO Digital Work" },
      { name: "description", content: "Selected websites, ecommerce platforms, mobile apps and growth campaigns by TRIOCTO." },
      { property: "og:title", content: "TRIOCTO Portfolio" },
      { property: "og:description", content: "Our digital work speaks for itself." },
      { property: "og:url", content: "/portfolio" },
    ],
    links: [{ rel: "canonical", href: "/portfolio" }],
  }),
  component: PortfolioPage,
});

type Project = {
  title: string;
  category: "Website" | "Ecommerce" | "Mobile App" | "Digital Marketing";
  result: string;
  challenge: string;
  solution: string;
  outcome: string;
  icon: keyof typeof Icons;
  gradient: string;
};

const projects: Project[] = [
  { title: "Modern Business Website", category: "Website", result: "+180% inbound leads", challenge: "Outdated brand site with poor mobile UX and minimal traffic.", solution: "Full redesign with custom CMS, performance-first build and on-page SEO.", outcome: "Lead volume nearly tripled and bounce rate dropped 42%.", icon: "Globe", gradient: "from-blue-500/40 to-indigo-500/40" },
  { title: "Ecommerce Shopping Store", category: "Ecommerce", result: "2.3x conversion rate", challenge: "Existing store had cart abandonment over 78%.", solution: "Streamlined checkout, fast PDPs and integrated trust signals.", outcome: "Conversion rate doubled and average order value rose 35%.", icon: "ShoppingCart", gradient: "from-red-500/40 to-pink-500/40" },
  { title: "Mobile App Interface", category: "Mobile App", result: "4.8★ App Store rating", challenge: "Concept for a fitness app needed a delightful first-time experience.", solution: "Custom onboarding, native-feel animations and offline-first architecture.", outcome: "20K downloads in launch month and a 4.8★ rating sustained.", icon: "Smartphone", gradient: "from-cyan-500/40 to-blue-500/40" },
  { title: "SEO Growth Campaign", category: "Digital Marketing", result: "+312% organic traffic", challenge: "Niche B2B brand invisible on competitive keywords.", solution: "Technical SEO overhaul, topic-cluster content strategy and outreach.", outcome: "First-page rankings on 40+ keywords within 6 months.", icon: "Search", gradient: "from-violet-500/40 to-fuchsia-500/40" },
  { title: "WordPress Maintenance Project", category: "Website", result: "99.99% uptime", challenge: "Frequent downtime, slow load times and plugin conflicts.", solution: "Managed hosting move, weekly updates and security hardening.", outcome: "Zero unplanned downtime and 2.4x faster page loads.", icon: "Settings", gradient: "from-emerald-500/40 to-teal-500/40" },
  { title: "Hosting Setup Project", category: "Website", result: "1.2s avg load time", challenge: "Enterprise client needed scalable infrastructure for traffic spikes.", solution: "Cloud-hosting architecture with CDN, caching and autoscaling.", outcome: "Handled 10x traffic spikes with no degradation.", icon: "Server", gradient: "from-orange-500/40 to-red-500/40" },
];

const FILTERS = ["All", "Website", "Ecommerce", "Mobile App", "Digital Marketing"] as const;

function PortfolioPage() {
  const { open } = useQuote();
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const [selected, setSelected] = useState<Project | null>(null);

  const visible = filter === "All" ? projects : projects.filter((p) => p.category === filter);

  return (
    <div>
      <section className="relative pt-20 pb-16 overflow-hidden">
        <TechBackground variant="hero" />
        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-xs tracking-[0.3em] text-[var(--neon-blue)] uppercase mb-3">Portfolio</p>
            <h1 className="font-display text-5xl sm:text-7xl font-bold">
              Our Digital Work <span className="gradient-text">Speaks For Itself</span>
            </h1>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-full px-5 py-2 text-sm font-semibold transition-all ${
                filter === f ? "gradient-brand text-white glow-mix" : "glass hover:bg-white/10"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {visible.map((p, i) => {
            const Icon = (Icons as any)[p.icon] ?? Icons.Sparkles;
            return (
              <Reveal key={p.title} delay={i * 70}>
                <div className="glass rounded-2xl overflow-hidden hover-lift group">
                  <div className={`relative aspect-video bg-gradient-to-br ${p.gradient} flex items-center justify-center overflow-hidden`}>
                    <div className="absolute inset-0 tech-grid opacity-30" />
                    <Icon className="relative h-16 w-16 text-white/90 group-hover:scale-110 transition-transform" />
                  </div>
                  <div className="p-5">
                    <p className="text-xs uppercase tracking-widest text-[var(--neon-blue)] mb-1">{p.category}</p>
                    <h3 className="font-display text-lg font-bold mb-1">{p.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{p.result}</p>
                    <button onClick={() => setSelected(p)} className="text-sm font-semibold text-[var(--neon-red)] hover:underline">View Details →</button>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="relative glass-strong rounded-3xl p-12 text-center overflow-hidden">
          <TechBackground />
          <h2 className="relative font-display text-3xl sm:text-5xl font-bold mb-4">
            Have a project in mind?
          </h2>
          <button onClick={() => open()} className="relative rounded-full gradient-brand px-7 py-3 text-sm font-semibold text-white animate-pulse-glow">
            Start Your Project
          </button>
        </div>
      </section>

      <Dialog open={!!selected} onOpenChange={(v) => !v && setSelected(null)}>
        <DialogContent className="glass-strong border-white/10 sm:max-w-lg">
          {selected && (
            <>
              <DialogHeader>
                <p className="text-xs uppercase tracking-widest text-[var(--neon-blue)]">{selected.category}</p>
                <DialogTitle className="text-2xl font-display">{selected.title}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-2 text-sm">
                <div>
                  <p className="font-semibold mb-1">Challenge</p>
                  <p className="text-muted-foreground">{selected.challenge}</p>
                </div>
                <div>
                  <p className="font-semibold mb-1">Solution</p>
                  <p className="text-muted-foreground">{selected.solution}</p>
                </div>
                <div>
                  <p className="font-semibold mb-1">Result</p>
                  <p className="gradient-text font-bold">{selected.outcome}</p>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
