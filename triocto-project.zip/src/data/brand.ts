export const BRAND = {
  name: "TRIOCTO",
  phone: "+91 84603 50645",
  phoneRaw: "+918460350645",
  phone2: "+91 87883 91613",
  email: "contact@triocto.com",
  address:
    "102, Vinayak Society, Opp. Greenpark Society, Sheetal Nagar, Akota, Vadodara, Gujarat - 390020",
  whatsappMessage: "Hi TRIOCTO, I want to discuss a project.",
  founded: "2026",
  founders: "Aakash Gandhi, Ketan Chaudhari & Sahas Thakery",
  socials: {
    facebook: "https://www.facebook.com/profile.php?id=61572063657731",
    instagram: "https://www.instagram.com/contact.triocto",
    linkedin: "https://www.linkedin.com/company/triocto-pvt-ltd",
  },
};

export const whatsappLink = () =>
  `https://wa.me/${BRAND.phoneRaw.replace("+", "")}?text=${encodeURIComponent(BRAND.whatsappMessage)}`;
