import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Calendar, ArrowLeft, ArrowRight } from "lucide-react";
import { TechBackground } from "@/components/TechBackground";
import { Reveal } from "@/components/Reveal";
import { getPost, blogPosts } from "@/data/blog";

export const Route = createFileRoute("/blog/$slug")({
  loader: ({ params }) => {
    const post = getPost(params.slug);
    if (!post) throw notFound();
    return { post };
  },
  head: ({ loaderData }) => {
    const p = loaderData?.post;
    if (!p) return {};
    return {
      meta: [
        { title: `${p.title} — TRIOCTO Blog` },
        { name: "description", content: p.excerpt },
        { property: "og:title", content: p.title },
        { property: "og:description", content: p.excerpt },
        { property: "og:type", content: "article" },
        { property: "og:url", content: `/blog/${p.slug}` },
      ],
      links: [{ rel: "canonical", href: `/blog/${p.slug}` }],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-4 py-32 text-center">
      <h1 className="font-display text-4xl font-bold mb-4">Post not found</h1>
      <Link to="/blog" className="text-[var(--neon-blue)] hover:underline">← Back to blog</Link>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="mx-auto max-w-3xl px-4 py-32 text-center">
      <h1 className="font-display text-3xl font-bold">Couldn't load post</h1>
      <p className="text-muted-foreground mt-2">{error.message}</p>
    </div>
  ),
  component: BlogPostPage,
});

function BlogPostPage() {
  const { post } = Route.useLoaderData();
  const related = blogPosts.filter((p) => p.slug !== post.slug).slice(0, 3);

  return (
    <div>
      <section className="relative pt-20 pb-12 overflow-hidden">
        <TechBackground variant="hero" />
        <div className="relative mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <Link to="/blog" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
            <ArrowLeft className="h-4 w-4" /> Back to Blog
          </Link>
          <Reveal>
            <div className="flex items-center gap-3 text-xs mb-4">
              <span className="rounded-full glass px-3 py-1 text-[var(--neon-blue)]">{post.category}</span>
              <span className="inline-flex items-center gap-1 text-muted-foreground"><Calendar className="h-3 w-3" /> {post.date}</span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold leading-tight">{post.title}</h1>
            <p className="mt-4 text-lg text-muted-foreground">{post.excerpt}</p>
          </Reveal>
        </div>
      </section>

      <article className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-5 text-base leading-relaxed text-muted-foreground">
          {post.content.map((para: string, i: number) => (
            <p key={i}>{para}</p>
          ))}
        </div>
      </article>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="font-display text-2xl sm:text-3xl font-bold mb-6">Related Posts</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {related.map((p) => (
            <Link key={p.slug} to="/blog/$slug" params={{ slug: p.slug }} className="block glass rounded-2xl p-5 hover-lift group">
              <span className="text-xs uppercase tracking-widest text-[var(--neon-red)]">{p.category}</span>
              <h3 className="font-display font-bold mt-2 group-hover:gradient-text transition-all">{p.title}</h3>
              <span className="mt-3 inline-flex items-center gap-1 text-sm text-[var(--neon-blue)]">Read <ArrowRight className="h-3 w-3" /></span>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="relative glass-strong rounded-3xl p-12 text-center overflow-hidden">
          <TechBackground />
          <h2 className="relative font-display text-3xl sm:text-4xl font-bold mb-4">
            Need help applying these ideas?
          </h2>
          <Link to="/contact" className="relative inline-flex rounded-full gradient-brand px-7 py-3 text-sm font-semibold text-white animate-pulse-glow">
            Contact TRIOCTO
          </Link>
        </div>
      </section>
    </div>
  );
}
