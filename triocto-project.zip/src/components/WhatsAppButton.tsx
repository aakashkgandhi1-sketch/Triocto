import { MessageCircle } from "lucide-react";
import { whatsappLink } from "@/data/brand";

export function WhatsAppButton() {
  return (
    <a
      href={whatsappLink()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with TRIOCTO on WhatsApp"
      className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-2xl hover:scale-110 transition-transform animate-pulse-glow"
      style={{ boxShadow: "0 0 30px rgba(37,211,102,0.6), 0 0 60px rgba(37,211,102,0.3)" }}
    >
      <MessageCircle className="h-7 w-7" strokeWidth={2.2} />
    </a>
  );
}
