import { createFileRoute } from "@tanstack/react-router";
import { Star, Quote } from "lucide-react";
import { TechBackground } from "@/components/TechBackground";
import { Reveal } from "@/components/Reveal";

export const Route = createFileRoute("/testimonials")({
  head: () => ({
    meta: [
      { title: "Testimonials — Client Reviews of TRIOCTO" },
      { name: "description", content: "Real reviews from TRIOCTO clients about our web design, development and digital marketing services." },
      { property: "og:title", content: "TRIOCTO Client Reviews" },
      { property: "og:description", content: "What our clients say about working with TRIOCTO." },
      { property: "og:url", content: "/testimonials" },
    ],
    links: [{ rel: "canonical", href: "/testimonials" }],
  }),
  component: TestimonialsPage,
});

const reviews = [
  { name: "Sheree Blair", text: "Thank you so much TRIOCTO team for giving me the best opportunity to work. Great experience with the company in web design and development." },
  { name: "Ingrid Levine London", text: "I am so impressed with TRIOCTO developing. They have done a fantastic job on website and very affordable. I highly recommend them." },
  { name: "Laura Kakulu", text: "TRIOCTO was extremely efficient. The communication was excellent and we are very happy with the result. Now our website is compatible with mobile." },
  { name: "Debby Dorsman", text: "Very good experience with team TRIOCTO, especially for their excellent work." },
  { name: "Sue Roberts", text: "Team TRIOCTO constructed a new website for us which is fast and efficient. They delivered on time." },
];

function TestimonialsPage() {
  return (
    <div>
      <section className="relative pt-20 pb-16 overflow-hidden">
        <TechBackground variant="hero" />
        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-xs tracking-[0.3em] text-[var(--neon-blue)] uppercase mb-3">Reviews Of Clients</p>
            <h1 className="font-display text-5xl sm:text-7xl font-bold">
              Client <span className="gradient-text">Reviews</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground">
              At TRIOCTO, our clients' satisfaction and success are at the core of everything we do.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {reviews.map((r, i) => (
            <Reveal key={r.name} delay={i * 80}>
              <div className="relative glass rounded-2xl p-7 hover-lift h-full">
                <Quote className="absolute top-4 right-4 h-8 w-8 text-[var(--neon-blue)]/20" />
                <div className="flex gap-1 mb-3 text-[var(--neon-blue)]">
                  {Array.from({ length: 5 }).map((_, k) => <Star key={k} className="h-4 w-4 fill-current" />)}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">"{r.text}"</p>
                <div className="mt-5 flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full gradient-brand flex items-center justify-center text-white font-bold">
                    {r.name.charAt(0)}
                  </div>
                  <p className="font-display font-semibold">{r.name}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}
