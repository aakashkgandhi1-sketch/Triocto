import { createContext, useContext, useState, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { services } from "@/data/services";
import { submitLead } from "@/lib/leads.functions";

type Ctx = { open: (presetService?: string) => void; close: () => void };
const QuoteCtx = createContext<Ctx | null>(null);

export const useQuote = () => {
  const ctx = useContext(QuoteCtx);
  if (!ctx) throw new Error("useQuote must be used inside QuoteProvider");
  return ctx;
};

export function QuoteProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [preset, setPreset] = useState<string | undefined>();
  const [submitting, setSubmitting] = useState(false);
  const submit = useServerFn(submitLead);

  const open = (presetService?: string) => {
    setPreset(presetService);
    setIsOpen(true);
  };
  const close = () => setIsOpen(false);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    setSubmitting(true);
    try {
      await submit({
        data: {
          source: "quote",
          name: String(fd.get("name") ?? ""),
          email: String(fd.get("email") ?? ""),
          phone: String(fd.get("phone") ?? ""),
          service: String(fd.get("service") ?? ""),
          budget: String(fd.get("budget") ?? ""),
          message: String(fd.get("message") ?? ""),
          pageUrl: typeof window !== "undefined" ? window.location.href : "",
        },
      });

      setIsOpen(false);
      toast.success("Thank you! TRIOCTO will contact you shortly.");
      form.reset();
    } catch (err: any) {
      toast.error(err?.message ?? "Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <QuoteCtx.Provider value={{ open, close }}>
      {children}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="glass-strong border-white/10 sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-display">
              Get Your <span className="gradient-text">Free Quote</span>
            </DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Tell us about your project — we'll get back within 24 hours.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={onSubmit} className="space-y-4 mt-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Label htmlFor="q-name">Name</Label>
                <Input id="q-name" name="name" required maxLength={100} className="bg-white/5 border-white/10" />
              </div>
              <div>
                <Label htmlFor="q-email">Email</Label>
                <Input id="q-email" name="email" type="email" required maxLength={255} className="bg-white/5 border-white/10" />
              </div>
              <div>
                <Label htmlFor="q-phone">Phone</Label>
                <Input id="q-phone" name="phone" type="tel" required maxLength={20} className="bg-white/5 border-white/10" />
              </div>
              <div>
                <Label htmlFor="q-budget">Budget Range</Label>
                <Select name="budget" defaultValue="negotiable">
                  <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="under-50k">Under ₹50,000</SelectItem>
                    <SelectItem value="50k-1L">₹50,000 – ₹1,00,000</SelectItem>
                    <SelectItem value="1L-5L">₹1,00,000 – ₹5,00,000</SelectItem>
                    <SelectItem value="5L+">₹5,00,000+</SelectItem>
                    <SelectItem value="negotiable">Let's discuss</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="q-service">Service Interested In</Label>
              <Select name="service" defaultValue={preset ?? services[0].title}>
                <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {services.map((s) => (
                    <SelectItem key={s.slug} value={s.title}>{s.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="q-message">Message</Label>
              <Textarea id="q-message" name="message" rows={4} maxLength={1000} className="bg-white/5 border-white/10" placeholder="Tell us about your project..." />
            </div>
            <Button type="submit" disabled={submitting} className="w-full gradient-brand glow-mix text-white font-semibold h-11 hover:opacity-90">
              {submitting ? "Sending..." : "Send Request"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </QuoteCtx.Provider>
  );
}
