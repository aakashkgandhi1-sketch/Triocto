
CREATE TABLE public.leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source text NOT NULL CHECK (source IN ('contact','quote')),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  service text,
  budget text,
  message text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT ALL ON public.leads TO service_role;

ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

-- No public policies: only service_role (backend) can access.
