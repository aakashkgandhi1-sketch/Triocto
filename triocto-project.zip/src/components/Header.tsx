import { useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X, Phone } from "lucide-react";
import { Logo } from "./Logo";
import { useQuote } from "./QuoteProvider";
import { whatsappLink, BRAND } from "@/data/brand";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/about-us", label: "About Us" },
  { to: "/services", label: "Services" },
  { to: "/portfolio", label: "Portfolio" },
  { to: "/pricing", label: "Pricing" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  const { open: openQuote } = useQuote();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header className="sticky top-0 z-40 w-full">
      <div className="glass-strong border-b border-white/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid min-h-20 grid-cols-[minmax(0,1fr)_auto] items-center gap-3 py-2 lg:min-h-28 lg:grid-cols-[auto_minmax(0,1fr)_auto] lg:gap-4">
            <Logo placement="header" />
            <nav className="hidden lg:flex items-center gap-1">
              {NAV.map((item) => {
                const active = pathname === item.to;
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    className={`relative px-3 py-2 text-sm font-medium transition-colors ${
                      active ? "text-foreground" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {item.label}
                    {active && (
                      <span className="absolute inset-x-3 -bottom-px h-px gradient-brand" />
                    )}
                  </Link>
                );
              })}
            </nav>
            <div className="flex items-center gap-2">
              <button
                onClick={() => openQuote()}
                className="hidden sm:inline-flex items-center rounded-full gradient-brand px-4 py-2 text-sm font-semibold text-white animate-pulse-glow hover:opacity-95 transition-opacity"
              >
                GET QUOTE
              </button>
              <a
                href={whatsappLink()}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp"
                className="hidden sm:inline-flex h-9 w-9 items-center justify-center rounded-full bg-[#25D366] text-white hover:scale-110 transition-transform"
              >
                <Phone className="h-4 w-4" />
              </a>
              <button
                aria-label="Toggle menu"
                onClick={() => setOpen(!open)}
                className="lg:hidden inline-flex h-9 w-9 items-center justify-center rounded-full glass"
              >
                {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>
          {open && (
            <div className="lg:hidden pb-4 animate-fade-up">
              <nav className="flex flex-col gap-1">
                {NAV.map((item) => (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setOpen(false)}
                    className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-white/5"
                  >
                    {item.label}
                  </Link>
                ))}
                <button
                  onClick={() => {
                    setOpen(false);
                    openQuote();
                  }}
                  className="mt-2 rounded-full gradient-brand px-4 py-2 text-sm font-semibold text-white"
                >
                  GET QUOTE
                </button>
                <a
                  href={`tel:${BRAND.phoneRaw}`}
                  className="rounded-full glass px-4 py-2 text-sm font-semibold text-center"
                >
                  Call {BRAND.phone}
                </a>
              </nav>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
